<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'headlink.php';?> 
    <link rel="stylesheet" href="css/style.css">
    <title>CAREER</title>
  </head>
  <body>
    <?php include 'menu.php';?>
    
    <!-- Footer -->
    <?php include'footer.php';?>
    <?php include'footerlink.php';?>
  </body>
</html>