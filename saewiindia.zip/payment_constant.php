<?php
	// define("API_KEY","rzp_test_skNjumYBKrOKZ2");
	define("API_KEY","rzp_live_ESJiSGIEkrg68p");
	// define("API_KEY","KVV2yNPLssjS3jUvH171bc3x");
	
?>