<section class="contact-section">
  <div class="container">
    <div class="row ">
      <div class="col-md-4 so">
        <a href="" title="" style="color: white" > <i class="fa fa-phone text" ></i>&nbsp; : 7362803453 / 8294823141</a>
      </div>
      <div class="col-md-4 so" >
        <a href="mailto:info@saewiindia.com" style="color: white" ><i class="fa fa-envelope text"></i> &nbsp;: info@saewiindia.com</a>
      </div>
      <div class="col-md-4">
         <div class="social" style="padding-left: 30px">
          <a class="btn btn-sm btn-warning" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
</section>


<section>
<nav class="navbar navbar-expand-lg navbar-light"  style="background:#fff;">
  <div class="container">
  
      <a class="navbar-brand" href="index.php">
      <div class="row">
      <div class="col-md-6 text-center">
      <img class="logo" src="images/logo.jpeg" alt="logo">
      </div>
      <div class="col-md-6 logo_brand">
      <b>SAEWI INDIA</b><p>(SOCIETY AGRICULTURE AND ENVIRONMENT WELFARE INDIA)</p><p> Opposite ST. Patrik chruch, Sisai Road Gumla, Jharkhand</p></a>
  </div>
  </div>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>
  
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto menu">
          <li class="nav-item ">
            <li class="nav-item "> <a class="nav-link" href="home.php" style="color: black">Dashboard</a> </li>
            <li class="nav-item "> <a class="nav-link" href="registrationlist.php" style="color: black">Registration List</a> </li>
          </li>
          <li class="nav-item"> <a class="nav-link" href="#" style="color: black">Career List</a> </li>
          <li class="nav-item"> <a class="nav-link" href="#" style="color: black">Contact Us List</a> </li>
          
          <!-- <li class="nav-item"> <a href="donate.php"><button type="button" class="btn btn-success">Donate Us</button></a></li> -->
        </ul>
      </div>
  </div>
</nav>
</section>