<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'headlink.php';?> 
    <link rel="stylesheet" href="css/style.css">
    <title>CLIENT</title>
  </head>
  <body>
    <?php include 'menu.php';?>
    <img width="100%" src="images/1500x500.jpg">
    <section class="join">
      <div class="container">
        <div class="col-md-12">
          <div class="jo">
            <div class="row">
              <div class="col-md-9">
                <center><h4 class="tit">We Are The Saviours Of The planet Earth</h4></center>
                <h5></h5>
                <center><button type="button" class="btn btn-outline-success">Apply For Volunteer</button></center>
              </div>
              <div class="col-md-3">
              <img width="100%" src="images/13.jpg">
              </div>
            </div>
          </div>
          <div class="jo">
            <div class="row">
              <div class="col-md-3">
                <img width="100%" src="images/IMG-20210506-WA0009.jpg">
              </div>
              <div class="col-md-9">
                <center><h4 class="tit">Jobs</h4></center>
              <p>SAEWI INDIA have technical staff, field executives, field workers in various ongoing projects and they are from different backgrounds. Instead of that we need more Human Resources. If any one feel interested to get work with us please mail us at saewiindia@gmail.com</p>
              <center><button type="button" class="btn btn-outline-success">Apply For Volunteer</button></center>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Footer -->
    <?php include'footer.php';?>
    <?php include'footerlink.php';?>
  </body>
</html>